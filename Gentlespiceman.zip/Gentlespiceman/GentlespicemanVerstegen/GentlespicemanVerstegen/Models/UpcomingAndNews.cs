﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GentlespicemanVerstegen.Models
{
    public class UpcomingAndNews
    {
            public News News { get; set; }
            public Upcoming Upcomings { get; set; }
    }
}
