﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GentlespicemanVerstegen.Models
{
    public class Upcoming
    {
        public int id { get; set; }
        public string title { get; set; }
        public string location { get; set; }
        public DateTime beginDate { get; set; }
        public DateTime endDate { get; set; }
    }
}
