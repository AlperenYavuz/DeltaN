﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GentlespicemanVerstegen.Models;
using System.Dynamic;

namespace GentlespicemanVerstegen.Controllers
{
    public class NewsController : Controller
    {
       
        public IActionResult Index()
        {
            IEnumerable<News> news = new List<News>()
            {
                new News() { id = 1, title = "Test news 1", category = "News" , image = "image.png" , content = "Lorem ipsum dolor si amet" , date = new DateTime(2017, 1, 18), },
                new News() { id = 2, title = "Test news 2", category = "Trends" , image = "image.png" , content = "Lorem ipsum dolor si amet" , date = new DateTime(2017, 2, 18) },
                new News() { id = 3, title = "Test news 3", category = "Innovations" , image = "image.png" , content = "Lorem ipsum dolor si amet" , date = new DateTime(2017, 3, 18) },
                new News() { id = 4, title = "Test news 4", category = "Stories" , image = "image.png" , content = "Lorem ipsum dolor si amet" , date = new DateTime(2017, 4, 18) },
                new News() { id = 5, title = "Test news 5", category = "News" , image = "image.png" , content = "Lorem ipsum dolor si amet" , date = new DateTime(2017, 1, 18) },
                new News() { id = 6, title = "Test news 6", category = "Trends" , image = "image.png" , content = "Lorem ipsum dolor si amet" , date = new DateTime(2017, 2, 18) },
                new News() { id = 7, title = "Test news 7", category = "Innovations" , image = "image.png" , content = "Lorem ipsum dolor si amet" , date = new DateTime(2017, 3, 18) },
                new News() { id = 8, title = "Test news 8", category = "Stories" , image = "image.png" , content = "Lorem ipsum dolor si amet" , date = new DateTime(2017, 4, 18) },
                new News() { id = 9, title = "Test news 9", category = "News" , image = "image.png" , content = "Lorem ipsum dolor si amet" , date = new DateTime(2017, 1, 18) },
            };

            IEnumerable<Upcoming> upcomings = new List<Upcoming>()
            {
                new Upcoming() { id = 1, title = "Spices & Herbs international 2018", location = "Amsterdam" ,  beginDate = new DateTime(2018, 12, 29) , endDate = new DateTime(2018, 12, 30) },
                new Upcoming() { id = 2, title = "Spices & Herbs international 2018", location = "Amsterdam" ,  beginDate = new DateTime(2018, 12, 29) , endDate = new DateTime(2018, 12, 30) },
                new Upcoming() { id = 3, title = "Spices & Herbs international 2018", location = "Amsterdam" ,  beginDate = new DateTime(2018, 12, 29) , endDate = new DateTime(2018, 12, 30) },
                new Upcoming() { id = 4, title = "Spices & Herbs international 2018", location = "Amsterdam" ,  beginDate = new DateTime(2018, 12, 29) , endDate = new DateTime(2018, 12, 30) },
            };

            IEnumerable<Upcoming> upcomingEvents = (from upcom in upcomings
                                                    where upcom.endDate > DateTime.Now
                                                    select upcom).Take(3).ToList();

            ViewData["events"] = upcomingEvents;

            return View(news);
        }      
    }
}