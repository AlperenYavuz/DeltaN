﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GentlespicemanVerstegen.Models;

namespace GentlespicemanVerstegen.Controllers
{
    public class ProductOverviewController : Controller
    {
        public IActionResult Index()
        {
            IEnumerable<Product> products = new List<Product>()
            {
                new Product() { id = 1, name = "Vlees marinade", category = "vlees" , type = "marinade" , description = "De lekkerste marinade voor op je vlees" , inhoud = "10 liter" },
                new Product() { id = 2, name = "Kip marinade", category = "kip" , type = "marinade" , description = "De lekkerste marinade voor op je kip" , inhoud = "5 liter" },
                new Product() { id = 3, name = "Vis marinade", category = "vis" , type = "marinade" , description = "De lekkerste marinade voor op je vis" , inhoud = "7 liter" },
                new Product() { id = 4, name = "Vegetarische marinade", category = "vegetarisch" , type = "marinade" , description = "De lekkerste marinade voor op je vegetarisch" , inhoud = "12 liter" },
            };

            return View(products);
        }
    }
}